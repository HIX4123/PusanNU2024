var studentName = "권민규";
var studentId = "202355517";
var introduceString =
    `제 이름은 '${studentName}'이고, 학번은 '${studentId}'입니다.`;
console.log(introduceString);
